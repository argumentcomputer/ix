Frozen C7 adapter handoff, preserved 2026-09-12.

The 53 adapter files were reconstructed from the six authenticated C2-C7 patches; every selected file starts as a new file in that patch sequence. Historical evidence and drivers are preserved byte for byte. They are not maintained programs. The maintained implementations and Lean CLI tests live in Ix/Certified, Ix/Kernel/Certified*, Ix/IxVM/Certified and Tests/Certified.

This archive is sufficient to recover the selected adapter sources and all retained differential fixtures. It is not a complete historical Ix base checkout: commit 3e7586a7adb0c6f3cd3ff5854da832701288ec90 was not available in the current repository. The historical reproduction script still requires that base and the separate model base. Current Ix validation does not depend on either checkout.
