/-
Copyright (c) 2026 Argument Computer Corporation.
SPDX-License-Identifier: MIT OR Apache-2.0
-/

import Lean
import Ix.Certified.ClaimCommand

/-! Trust, runtime and premise inventory of the versioned semantic claim
checker, source command and actual TcM acceptance boundary. -/

open Lean Lean.Elab Command

namespace Ix.Certified.ClaimAudit

def roots : Array Lean.Name := #[
  `Ix.Certified.TreeOpening.membership, `Ix.Certified.TreeOpening.unique,
  `Ix.Certified.treeLeaves_join, `Ix.Certified.EnvelopeReading.unique,
  `Ix.Certified.readEnvelope?, `Ix.Certified.readTree?,
  `Ix.Certified.LogicalChecking.original_subject, `Ix.Certified.LogicalChecking.original_frontier,
  `Ix.Certified.LogicalChecking.logical_policy, `Ix.Certified.LogicalChecking.closed_frontier,
  `Ix.Certified.LogicalReceipt.subject_meaning, `Ix.Certified.LogicalReceipt.closed_subject_meaning,
  `Ix.Certified.LogicalReceipt.no_False,
  `Ix.Certified.RevealReceipt.meaning, `Ix.Certified.ClaimReceipt.meaning,
  `Ix.Certified.accepted_claim_meaning, `Ix.Certified.evaluation_not_semantic,
  `Ix.Certified.membership_not_leaf, `Ix.Certified.revelation_not_leaf,
  `Ix.Tc.TcM.checkClaimCertified_success,
  `Ix.Tc.certifiedClaimStep_failure, `Ix.Tc.certifiedClaimStep_success,
  `Ix.Tc.accepted_tc_claim_meaning,
  `Ix.Certified.ClaimCommand.readRequest,
  `Ix.Certified.ClaimCommand.run_success, `Ix.Certified.ClaimCommand.run_meaning]

def premises : Array Lean.Name := #[
  `Ix.Certified.Protocol.current, `Ix.Certified.envelopeMagic,
  `Ix.Certified.putEnvelope, `Ix.Certified.getEnvelope,
  `Ix.Certified.EnvelopeReading.mk, `Ix.Certified.TreeOpening.mk,
  `Ix.Certified.OptionalTreeOpening.mk, `Ix.Certified.SubjectView.mk,
  `Ix.Certified.PreparedLeaf.mk, `Ix.Certified.ContentView.mk,
  `Ix.Certified.ownedReferences, `Ix.Certified.claimFrontier,
  `Ix.Certified.LogicalChecking.mk, `Ix.Certified.LogicalReceipt.mk,
  `Ix.Certified.SubjectsInterpreted, `Ix.Certified.LogicalMeaning,
  `Ix.Certified.RevealMatches, `Ix.Certified.ConstructorMatches,
  `Ix.Certified.ConstructorsMatch, `Ix.Certified.MutMatches,
  `Ix.Certified.ComponentsMatch, `Ix.Certified.RulesMatch,
  `Ix.Certified.RevealMeaning, `Ix.Certified.SemanticClaimMeaning]

private def constants (info : Lean.ConstantInfo) : Array Lean.Name :=
  info.type.getUsedConstants ++ match info with
  | .thmInfo value => value.value.getUsedConstants
  | .defnInfo value => value.value.getUsedConstants
  | .opaqueInfo value => value.value.getUsedConstants
  | .inductInfo value => value.ctors.toArray
  | _ => #[]

private partial def closure (env : Lean.Environment) (pending : List Lean.Name)
    (seen : NameSet := {}) : NameSet :=
  match pending with
  | [] => seen
  | name :: rest =>
    if seen.contains name then closure env rest seen
    else match env.find? name with
    | none => closure env rest (seen.insert name)
    | some info => closure env ((constants info).toList ++ rest) (seen.insert name)

run_cmd do
  let env ← getEnv
  for root in roots do
    let some info := env.find? root | throwError "C6 claim audit: missing root {root}"
    let axioms ← collectAxioms root
    for a in axioms do
      unless #[`propext, `Classical.choice, `Quot.sound].contains a do
        throwError "C6 claim root {root} reaches unapproved axiom {a}"
    liftTermElabM do logInfo m!"ROOT {root}\n{← Meta.ppExpr info.type}\nAXIOMS {axioms}"
  for name in premises do
    let some info := env.find? name | throwError "C6 claim audit: missing premise {name}"
    liftTermElabM do
      logInfo m!"PREMISE {name}\n{← Meta.ppExpr info.type}"
      if let .defnInfo value := info then logInfo m!"DEFINITION\n{← Meta.ppExpr value.value}"
  let reachable := (closure env roots.toList).toList.mergeSort (fun a b => a.toString < b.toString)
  let mut externs : Array Lean.Name := #[]
  let mut replacements : Array (Lean.Name × Lean.Name) := #[]
  let mut workers : Array Lean.Name := #[]
  for name in reachable do
    if #[`Ix, `Ixon, `Blake3, `Address].any (·.isPrefixOf name) then
      if Lean.isExtern env name then externs := externs.push name
      if let some other := Lean.Compiler.getImplementedBy? env name then
        replacements := replacements.push (name, other)
      if let some other := (Lean.Compiler.CSimp.ext.getState env).map.find? name then
        replacements := replacements.push (name, other.toDeclName)
      if let some (.defnInfo definition) := env.find? name then
        unless definition.safety == .safe do
          if name.toString.endsWith "._unsafe_rec" then workers := workers.push name
          else throwError "C6 claim reaches unaudited unsafe/partial code: {name}"
  unless externs == #[`Blake3.Rust.hasherFinalize, `Blake3.Rust.hasherInit,
      `Blake3.Rust.hasherInitDeriveKey, `Blake3.Rust.hasherInitKeyed, `Blake3.Rust.hasherUpdate] do
    throwError "C6 claim runtime extern inventory changed: {externs}"
  unless replacements.isEmpty do throwError "C6 claim runtime replacements changed: {replacements}"
  logInfo m!"C6 claim ROOTS {roots.size}; REACHABLE DECLARATIONS {reachable.length}"
  logInfo m!"RUNTIME EXTERNS {externs}\nRECURSION WORKERS {workers}"
  logInfo "Every claim model premise is produced by source and dependency validation. Standard Lean execution and BLAKE3 FFI remain explicit runtime boundaries."

end Ix.Certified.ClaimAudit
