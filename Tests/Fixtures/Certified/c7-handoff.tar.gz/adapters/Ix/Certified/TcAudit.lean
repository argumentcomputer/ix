/-
Copyright (c) 2026 Argument Computer Corporation.
SPDX-License-Identifier: MIT OR Apache-2.0
-/

import Lean
import Ix.Tc.Certified
import Ix.Certified.Command

/-! The C5 audit covers the actual TcM certified entry points, the decoder
cache and source receipts. It does not promote legacy TcM successes. -/

open Lean Lean.Elab Command

namespace Ix.Certified.TcAudit

def roots : Array Lean.Name := #[
  `Ix.Certified.constantBytes?, `Ix.Certified.decodeObject_complete,
  `Ix.Certified.decodeNatural_complete,
  `Ix.Certified.SourceSnapshot.prepare_eq, `Ix.Certified.SourceSnapshot.prepareStore_eq,
  `Ix.Certified.SourceSnapshot.objects_from_source, `Ix.Certified.SourceSnapshot.naturals_from_source,
  `Ix.Certified.SourceReceipt.serialized, `Ix.Certified.StoreReceipt.serialized,
  `Ix.Certified.accepted_serialized_store_has_model,
  `Ix.Tc.TcM.checkCertified_success, `Ix.Tc.TcM.checkCertified_failure,
  `Ix.Tc.TcM.checkStoreCertified_success,
  `Ix.Tc.certifiedStep_success, `Ix.Tc.certifiedStep_failure,
  `Ix.Tc.certifiedStoreStep_success, `Ix.Tc.certifiedStoreStep_failure,
  `Ix.Tc.initialCertifiedState, `Ix.Tc.accepted_tc_has_model,
  `Ix.Tc.accepted_tc_store_has_model, `Ix.Tc.no_tc_proof_of_False,
  `Ix.Certified.Command.run_success]

def premises : Array Lean.Name := #[
  `Ix.Certified.InputCache.mk, `Ix.Certified.CachedObject.mk, `Ix.Certified.CachedNatural.mk,
  `Ix.Certified.DecodedObject, `Ix.Certified.DecodedNatural,
  `Ix.Certified.SourceObject.mk, `Ix.Certified.SourceNatural.mk,
  `Ix.Certified.SourceReceipt.mk, `Ix.Certified.StoreReceipt.mk,
  `Ix.Certified.InputSelection.mk, `Ix.Certified.subjectReferences?,
  `Ix.Tc.CertifiedState.mk]

private def constants (info : Lean.ConstantInfo) : Array Lean.Name :=
  info.type.getUsedConstants ++ match info with
  | .thmInfo value => value.value.getUsedConstants
  | .defnInfo value => value.value.getUsedConstants
  | .opaqueInfo value => value.value.getUsedConstants
  | .inductInfo value => value.ctors.toArray
  | _ => #[]

private partial def closure (env : Lean.Environment) (pending : List Lean.Name)
    (seen : NameSet := {}) : NameSet :=
  match pending with
  | [] => seen
  | name :: rest =>
    if seen.contains name then closure env rest seen
    else match env.find? name with
    | none => closure env rest (seen.insert name)
    | some info => closure env ((constants info).toList ++ rest) (seen.insert name)

run_cmd do
  let env ← getEnv
  for root in roots do
    let some info := env.find? root | throwError "C5 audit: missing root {root}"
    let axioms ← collectAxioms root
    for a in axioms do
      unless #[`propext, `Classical.choice, `Quot.sound].contains a do
        throwError "C5 root {root} reaches unapproved axiom {a}"
    liftTermElabM do logInfo m!"ROOT {root}\n{← Meta.ppExpr info.type}\nAXIOMS {axioms}"
  for name in premises do
    let some info := env.find? name | throwError "C5 audit: missing premise {name}"
    liftTermElabM do
      logInfo m!"PREMISE {name}\n{← Meta.ppExpr info.type}"
      if let .defnInfo value := info then logInfo m!"DEFINITION\n{← Meta.ppExpr value.value}"
  let reachable := (closure env roots.toList).toList.mergeSort (fun a b => a.toString < b.toString)
  let mut externs : Array Lean.Name := #[]
  let mut replacements : Array (Lean.Name × Lean.Name) := #[]
  let mut workers : Array Lean.Name := #[]
  for name in reachable do
    if #[`Ix, `Ixon, `Blake3, `Address].any (·.isPrefixOf name) then
      if Lean.isExtern env name then externs := externs.push name
      if let some other := Lean.Compiler.getImplementedBy? env name then
        replacements := replacements.push (name, other)
      if let some other := (Lean.Compiler.CSimp.ext.getState env).map.find? name then
        replacements := replacements.push (name, other.toDeclName)
      if let some (.defnInfo definition) := env.find? name then
        unless definition.safety == .safe do
          if name.toString.endsWith "._unsafe_rec" then workers := workers.push name
          else throwError "C5 reaches unaudited unsafe/partial code: {name}"
  unless externs == #[`Blake3.Rust.hasherFinalize, `Blake3.Rust.hasherInit,
      `Blake3.Rust.hasherInitDeriveKey, `Blake3.Rust.hasherInitKeyed, `Blake3.Rust.hasherUpdate] do
    throwError "C5 runtime extern inventory changed: {externs}"
  unless replacements.isEmpty do throwError "C5 runtime replacements changed: {replacements}"
  logInfo m!"C5 ROOTS {roots.size}; REACHABLE DECLARATIONS {reachable.length}"
  logInfo m!"RUNTIME EXTERNS {externs}\nRECURSION WORKERS {workers}"
  logInfo "Every model premise is produced by source validation. Standard Lean execution and BLAKE3 FFI remain explicit runtime boundaries."

end Ix.Certified.TcAudit
