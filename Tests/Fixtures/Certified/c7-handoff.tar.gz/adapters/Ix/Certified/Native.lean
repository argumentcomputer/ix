/-
Copyright (c) 2026 Argument Computer Corporation.
SPDX-License-Identifier: MIT OR Apache-2.0
-/

import Ix.Aiur.Protocol

/-! Observational C2 counters. These externs are outside the mathematical
certified target, and their output never authorizes acceptance. -/

namespace Ix.Certified.Native

@[extern "rs_aiur_system_constraint_counts"]
opaque constraintCounts : @& Aiur.AiurSystem → Array Nat

@[extern "rs_aiur_toplevel_execute_metrics"]
private opaque executeMetrics' : @& Aiur.Bytecode.Toplevel →
  @& Aiur.Bytecode.FunIdx → @& Array Aiur.G →
  (ioData : @& Array (Aiur.G × Array Aiur.G)) →
  (ioMap : @& Array ((Aiur.G × Array Aiur.G) × Aiur.IOKeyInfo)) →
  Except String (Aiur.ExecuteResult × Nat × Nat)

def executeMetrics (toplevel : Aiur.Bytecode.Toplevel)
    (funIdx : Aiur.Bytecode.FunIdx) (args : Array Aiur.G) (io : Aiur.IOBuffer) :
    Except String (Aiur.ExecuteResult × Nat × Nat) :=
  executeMetrics' toplevel funIdx args io.data.toArray io.map.toArray

end Ix.Certified.Native
