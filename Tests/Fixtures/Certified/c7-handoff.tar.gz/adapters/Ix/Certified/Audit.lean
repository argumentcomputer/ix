/-
Copyright (c) 2026 Argument Computer Corporation.
SPDX-License-Identifier: MIT OR Apache-2.0
-/

import Lean
import Ix.Certified.Bytes

/-!
The serialized host adapter has its own audit. This is not the pure model's
import boundary or an Aiur compiler/AIR soundness theorem. Foreign hashing and
its output contract remain explicit runtime dependencies.
-/

open Lean Lean.Elab Command

namespace Ix.Certified.Audit

def roots : Array Lean.Name := #[
  `Ix.Certified.decodeObject?, `Ix.Certified.decodeNatural?,
  `Ix.Certified.readSignature?, `Ix.Certified.prepare?,
  `Ix.Certified.acceptsSerialized_prepared,
  `Ix.Certified.accepted_serialized_has_model,
  `Ix.Certified.no_serialized_proof_of_False]

private def constants (info : Lean.ConstantInfo) : Array Lean.Name :=
  info.type.getUsedConstants ++ match info with
  | .thmInfo value => value.value.getUsedConstants
  | .defnInfo value => value.value.getUsedConstants
  | .opaqueInfo value => value.value.getUsedConstants
  | .inductInfo value => value.ctors.toArray
  | _ => #[]

private partial def closure (env : Lean.Environment) (pending : List Lean.Name)
    (seen : NameSet := {}) : NameSet :=
  match pending with
  | [] => seen
  | name :: rest =>
    if seen.contains name then closure env rest seen
    else match env.find? name with
    | none => closure env rest (seen.insert name)
    | some info => closure env ((constants info).toList ++ rest) (seen.insert name)

run_cmd do
  let env ← getEnv
  for root in roots do
    let some info := env.find? root | throwError "serialized audit: missing root {root}"
    let axioms ← Lean.collectAxioms root
    for axiomName in axioms do
      unless #[`propext, `Classical.choice, `Quot.sound].contains axiomName do
        throwError "serialized root {root} reaches unapproved axiom {axiomName}"
    liftTermElabM do
      logInfo m!"ROOT {root}\n{← Meta.ppExpr info.type}\nAXIOMS {axioms}"
  let reachable := (closure env roots.toList).toList.mergeSort (fun a b => a.toString < b.toString)
  let mut externs : Array Lean.Name := #[]
  let mut replacements : Array (Lean.Name × Lean.Name) := #[]
  for name in reachable do
    if (`Ix).isPrefixOf name || (`Ixon).isPrefixOf name || (`Blake3).isPrefixOf name ||
        (`Address).isPrefixOf name then
      if Lean.isExtern env name then externs := externs.push name
      if let some other := Lean.Compiler.getImplementedBy? env name then
        replacements := replacements.push (name, other)
      if let some other := (Lean.Compiler.CSimp.ext.getState env).map.find? name then
        replacements := replacements.push (name, other.toDeclName)
  unless externs == #[`Blake3.Rust.hasherFinalize, `Blake3.Rust.hasherInit,
      `Blake3.Rust.hasherInitDeriveKey, `Blake3.Rust.hasherInitKeyed,
      `Blake3.Rust.hasherUpdate] do
    throwError "serialized runtime extern inventory changed: {externs}"
  unless replacements.isEmpty do
    throwError "serialized runtime replacements changed: {replacements}"
  logInfo m!"SERIALIZED ROOTS {roots.size}; REACHABLE DECLARATIONS {reachable.length}"
  logInfo m!"RUNTIME EXTERNS {externs}"
  logInfo "Runtime inventory records the foreign hashing interface; it does not prove FFI execution correct."

end Ix.Certified.Audit
