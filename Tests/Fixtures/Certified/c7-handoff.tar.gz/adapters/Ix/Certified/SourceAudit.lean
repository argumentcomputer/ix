/-
Copyright (c) 2026 Argument Computer Corporation.
SPDX-License-Identifier: MIT OR Apache-2.0
-/

import Lean
import Ix.Certified.SourceMeaning

/-! The C6 source audit freezes original expression/statement meaning and
its connection to the actual canonical source bytes. Claim composition and
backend execution are audited by their separate roots when connected. -/

open Lean Lean.Elab Command

namespace Ix.Certified.SourceAudit

def roots : Array Lean.Name := #[
  `Ix.Certified.resolveReference_iff, `Ix.Certified.readLevel_value,
  `Ix.Certified.readExpr_sound, `Ix.Certified.ExprReading.unique,
  `Ix.Certified.readExpr_fuel_independent,
  `Ix.Certified.readBlock_sourceHeader, `Ix.Certified.readStore_sourceHeader,
  `Ix.Certified.SourceSnapshot.object_bytes, `Ix.Certified.SourceSnapshot.natural_bytes,
  `Ix.Certified.readSignature_sound,
  `Ix.Certified.StoreReceipt.subject_meaning, `Ix.Certified.SourceReceipt.proposition_meaning,
  `Ix.Certified.StoreReceipt.subject_coverage]

def premises : Array Lean.Name := #[
  `Ix.Certified.MemberMeaning, `Ix.Certified.ReferenceTarget, `Ix.Certified.ReferenceMeaning,
  `Ix.Certified.LevelsReading.nil, `Ix.Certified.LevelsReading.cons,
  `Ix.Certified.ExprReading.var, `Ix.Certified.ExprReading.sort, `Ix.Certified.ExprReading.ref,
  `Ix.Certified.ExprReading.recur, `Ix.Certified.ExprReading.app, `Ix.Certified.ExprReading.lam,
  `Ix.Certified.ExprReading.all, `Ix.Certified.ExprReading.prj, `Ix.Certified.ExprReading.nat,
  `Ix.Certified.ExprReading.share, `Ix.Certified.rawHeader?,
  `Ix.Certified.ObjectBytes, `Ix.Certified.NaturalBytes,
  `Ix.Certified.SignatureReading, `Ix.Certified.SourceDeclarationReading, `Ix.Certified.SubjectReading]

private def constants (info : Lean.ConstantInfo) : Array Lean.Name :=
  info.type.getUsedConstants ++ match info with
  | .thmInfo value => value.value.getUsedConstants
  | .defnInfo value => value.value.getUsedConstants
  | .opaqueInfo value => value.value.getUsedConstants
  | .inductInfo value => value.ctors.toArray
  | _ => #[]

private partial def closure (env : Lean.Environment) (pending : List Lean.Name)
    (seen : NameSet := {}) : NameSet :=
  match pending with
  | [] => seen
  | name :: rest =>
    if seen.contains name then closure env rest seen
    else match env.find? name with
    | none => closure env rest (seen.insert name)
    | some info => closure env ((constants info).toList ++ rest) (seen.insert name)

run_cmd do
  let env ← getEnv
  for root in roots do
    let some info := env.find? root | throwError "C6 source audit: missing root {root}"
    let axioms ← collectAxioms root
    for a in axioms do
      unless #[`propext, `Classical.choice, `Quot.sound].contains a do
        throwError "C6 source root {root} reaches unapproved axiom {a}"
    liftTermElabM do logInfo m!"ROOT {root}\n{← Meta.ppExpr info.type}\nAXIOMS {axioms}"
  for name in premises do
    let some info := env.find? name | throwError "C6 source audit: missing premise {name}"
    liftTermElabM do
      logInfo m!"PREMISE {name}\n{← Meta.ppExpr info.type}"
      if let .defnInfo value := info then logInfo m!"DEFINITION\n{← Meta.ppExpr value.value}"
  let reachable := (closure env roots.toList).toList.mergeSort (fun a b => a.toString < b.toString)
  let mut externs : Array Lean.Name := #[]
  let mut replacements : Array (Lean.Name × Lean.Name) := #[]
  let mut workers : Array Lean.Name := #[]
  for name in reachable do
    if #[`Ix, `Ixon, `Blake3, `Address].any (·.isPrefixOf name) then
      if Lean.isExtern env name then externs := externs.push name
      if let some other := Lean.Compiler.getImplementedBy? env name then
        replacements := replacements.push (name, other)
      if let some other := (Lean.Compiler.CSimp.ext.getState env).map.find? name then
        replacements := replacements.push (name, other.toDeclName)
      if let some (.defnInfo definition) := env.find? name then
        unless definition.safety == .safe do
          if name.toString.endsWith "._unsafe_rec" then workers := workers.push name
          else throwError "C6 source reaches unaudited unsafe/partial code: {name}"
  unless externs == #[`Blake3.Rust.hasherFinalize, `Blake3.Rust.hasherInit,
      `Blake3.Rust.hasherInitDeriveKey, `Blake3.Rust.hasherInitKeyed, `Blake3.Rust.hasherUpdate] do
    throwError "C6 source runtime extern inventory changed: {externs}"
  unless replacements.isEmpty do throwError "C6 source runtime replacements changed: {replacements}"
  logInfo m!"C6 source ROOTS {roots.size}; REACHABLE DECLARATIONS {reachable.length}"
  logInfo m!"RUNTIME EXTERNS {externs}\nRECURSION WORKERS {workers}"
  logInfo "Every model premise is produced by source validation. Standard Lean execution and BLAKE3 FFI remain explicit runtime boundaries."

end Ix.Certified.SourceAudit
