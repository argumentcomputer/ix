/-
Copyright (c) 2026 Argument Computer Corporation.
SPDX-License-Identifier: MIT OR Apache-2.0
-/

import Lean
import Ix.Certified.ClaimCommand
import Ix.Certified.Command

/-! Trust, runtime and premise inventory of the versioned semantic claim
checker, source command and actual TcM acceptance boundary. -/

open Lean Lean.Elab Command

namespace Ix.Certified.ModeledAudit

def roots : Array Lean.Name := #[
  `Lean4Ix.Certified.Modeled.check?_sound,
  `Lean4Ix.Certified.Modeled.checkEquation?_sound,
  `Lean4Ix.Certified.Modeled.assignment_realizes,
  `Lean4Ix.Certified.Modeled.assignment_agrees,
  `Lean4Ix.Certified.checkModeledExtension?,
  `Lean4Ix.Certificate.Modeled.witness?,
  `Lean4Ix.Certificate.sourceGroup?,
  `Lean4Ix.Certificate.proofWitness?,
  `Ix.Certified.modelCandidate?, `Ix.Certified.modelCandidates?,
  `Ix.Certified.ModelHint.readOptional, `Ix.Certified.ModelHint.read,
  `Ix.Certified.suggestSource?, `Ix.Certified.suggestStore?,
  `Ix.Certified.Command.readRequest, `Ix.Certified.Command.run_success,
  `Ix.Certified.suggestLogical?, `Ix.Certified.ClaimCommand.readRequest,
  `Ix.Certified.ClaimCommand.run_meaning,
  `Ix.Tc.acceptsCertifiedSource, `Ix.Tc.acceptsCertifiedStoreSource,
  `Ix.Tc.accepted_tc_claim_meaning]

def premises : Array Lean.Name := #[
  `Ix.Certified.Protocol.current,
  `Ix.Certified.ModelHint.mk, `Ix.Certified.ModelRuleHints.mk,
  `Ix.Certified.ModelProofHint.mk,
  `Lean4Ix.Certificate.Modeled.Candidate.mk,
  `Lean4Ix.Certificate.Modeled.ProofHint.mk,
  `Lean4Ix.Certified.Modeled.Witness.mk,
  `Lean4Ix.Certified.Modeled.Checked.mk,
  `Lean4Ix.Certified.Modeled.SourceMatches,
  `Lean4Ix.Certified.Modeled.sourceRefs?,
  `Lean4Ix.Certified.Modeled.recursorSource?,
  `Lean4Ix.Certified.Modeled.majorSource?,
  `Lean4Ix.Certified.Modeled.ruleSource?,
  `Lean4Ix.Certified.Modeled.Companion.entry,
  `Lean4Ix.Certified.Modeled.CompanionChecked.mk,
  `Lean4Ix.Certified.Modeled.CheckedCompanions.mk,
  `Lean4Ix.Certified.Modeled.CheckedEquation.mk,
  `Lean4Ix.Certified.Modeled.checkEquation?]

private def constants (info : Lean.ConstantInfo) : Array Lean.Name :=
  info.type.getUsedConstants ++ match info with
  | .thmInfo value => value.value.getUsedConstants
  | .defnInfo value => value.value.getUsedConstants
  | .opaqueInfo value => value.value.getUsedConstants
  | .inductInfo value => value.ctors.toArray
  | _ => #[]

private partial def closure (env : Lean.Environment) (pending : List Lean.Name)
    (seen : NameSet := {}) : NameSet :=
  match pending with
  | [] => seen
  | name :: rest =>
    if seen.contains name then closure env rest seen
    else match env.find? name with
    | none => closure env rest (seen.insert name)
    | some info => closure env ((constants info).toList ++ rest) (seen.insert name)

run_cmd do
  let env ← getEnv
  for root in roots do
    let some info := env.find? root | throwError "C7 modeled audit: missing root {root}"
    let axioms ← collectAxioms root
    for a in axioms do
      unless #[`propext, `Classical.choice, `Quot.sound].contains a do
        throwError "C7 modeled root {root} reaches unapproved axiom {a}"
    liftTermElabM do logInfo m!"ROOT {root}\n{← Meta.ppExpr info.type}\nAXIOMS {axioms}"
  for name in premises do
    let some info := env.find? name | throwError "C7 modeled audit: missing premise {name}"
    liftTermElabM do
      logInfo m!"PREMISE {name}\n{← Meta.ppExpr info.type}"
      if let .defnInfo value := info then logInfo m!"DEFINITION\n{← Meta.ppExpr value.value}"
  let reachable := (closure env roots.toList).toList.mergeSort (fun a b => a.toString < b.toString)
  let mut externs : Array Lean.Name := #[]
  let mut replacements : Array (Lean.Name × Lean.Name) := #[]
  let mut workers : Array Lean.Name := #[]
  for name in reachable do
    if #[`Ix, `Ixon, `Blake3, `Address].any (·.isPrefixOf name) then
      if Lean.isExtern env name then externs := externs.push name
      if let some other := Lean.Compiler.getImplementedBy? env name then
        replacements := replacements.push (name, other)
      if let some other := (Lean.Compiler.CSimp.ext.getState env).map.find? name then
        replacements := replacements.push (name, other.toDeclName)
      if let some (.defnInfo definition) := env.find? name then
        unless definition.safety == .safe do
          if name.toString.endsWith "._unsafe_rec" then workers := workers.push name
          else throwError "C7 modeled reaches unaudited unsafe/partial code: {name}"
  unless externs == #[`Blake3.Rust.hasherFinalize, `Blake3.Rust.hasherInit,
      `Blake3.Rust.hasherInitDeriveKey, `Blake3.Rust.hasherInitKeyed, `Blake3.Rust.hasherUpdate] do
    throwError "C7 modeled runtime extern inventory changed: {externs}"
  unless replacements.isEmpty do throwError "C7 modeled runtime replacements changed: {replacements}"
  logInfo m!"C7 modeled ROOTS {roots.size}; REACHABLE DECLARATIONS {reachable.length}"
  logInfo m!"RUNTIME EXTERNS {externs}\nRECURSION WORKERS {workers}"
  logInfo "Every modeled declaration and whole source equation is checked before publication; hints contain only selected source references. Standard Lean execution and BLAKE3 FFI remain explicit runtime boundaries."

end Ix.Certified.ModeledAudit
